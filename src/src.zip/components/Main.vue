<template>
    <main>
        This is the main content

        <ol>
            <li>Banana</li>
            <li>Batag</li>
            <li>Saging</li>
        </ol>
    </main>
</template>


<script>
    import {defineComponent} from 'vue';

    export default defineComponent({
        name: "Main",

        /** DATA */
        data() {
            return {

            }
        },

        /** COMPONENTS */
        components: {

        },

        /** COMPUTED PROPERTIES */
        computed: {

        },

        /** METHODS */
        methods: {

        }
    })
</script>



<style scoped>

</style>

<template>
    <app-header user="Arvic Babol" user-type="Admin"/>
    <app-sidebar/>
    <app-main/>
    <app-footer/>
</template>


<script>
    import Header from "./components/Header.vue";
    import Sidebar from "./components/Sidebar.vue";
    import Main from "./components/Main.vue";
    import Footer from "./components/Footer.vue";
    export default {
        name: 'App',

        /** DATA */
        data() {
            return {
                message: ""
            }
        },

        /** COMPONENTS */
        components: {
            'app-header' : Header,
            'app-sidebar': Sidebar,
            'app-main'   : Main,
            'app-footer' : Footer
        },

        /** COMPUTED PROPERTIES */
        computed: {

        },

        /** METHODS */
        methods: {

        }
    }
</script>


<style>

</style>

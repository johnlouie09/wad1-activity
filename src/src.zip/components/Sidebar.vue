<template>
    <aside>
        <ul>
            <li>Home</li>
            <li>About</li>
            <li>Contact Us</li>
        </ul>
    </aside>
</template>


<script>
    import {defineComponent} from 'vue';

    export default defineComponent({
        name: "Sidebar",

        /** DATA */
        data() {
            return {

            }
        },

        /** COMPONENTS */
        components: {

        },

        /** COMPUTED PROPERTIES */
        computed: {

        },

        /** METHODS */
        methods: {

        }
    })
</script>



<style scoped>
    li {
        font-size: 20px;
        color: brown;
        font-family: Arial, sans-serif;
    }

    aside {
        background: yellow;
    }
</style>

<template>
    <p>Copyright &copy; 2023</p>
</template>


<script>
    import {defineComponent} from 'vue';

    export default defineComponent({
        name: "Footer",

        /** DATA */
        data() {
            return {

            }
        },

        /** COMPONENTS */
        components: {

        },

        /** COMPUTED PROPERTIES */
        computed: {

        },

        /** METHODS */
        methods: {

        }
    })
</script>



<style scoped>

</style>

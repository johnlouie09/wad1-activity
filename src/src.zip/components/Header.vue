<template>
    <header>
        <h1>{{ title }}</h1>
        <p>
            Current User:
            <span style="color: red">{{ user }}</span>
            <small style="padding-left: 15px;">{{ userType }}</small>
        </p>
    </header>
</template>


<script>
    import {defineComponent} from 'vue';

    export default defineComponent({
        name: "Header",

        /** DATA */
        data() {
            return {
                title: "ACLC College of Iriga"
            }
        },

        /** PROPS */
        props: {
            user: {
                type: String,
                required: true
            },
            userType: {
                type: String,
                required: true
            },
            age: {
                type: Number
            }
        },

        /** COMPONENTS */
        components: {

        },

        /** COMPUTED PROPERTIES */
        computed: {

        },

        /** METHODS */
        methods: {

        }
    })
</script>



<style scoped>

</style>
